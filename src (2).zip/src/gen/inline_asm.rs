use super::*;

use crate::node;

impl AsmEmitter {
    pub(super) fn deploy_inline_asm(
        &mut self,
        name: &String,
        dst: &usize,
    ) {

        let mut pushed_regs: Vec<String> = Vec::new();

        if self.asm_fmt
            .inline_asm_list()
            .iter()
            .find(|v| v.as_str() == name.as_str())
            .is_some()
        {
                // もしinlineアセンブラの中に現在使用中のレジスタがある場合は
                // スタックするアセンブリコードを生成する
                self.extract_operand_text(dst);

                println!("{}", name);

            while let Some(poped) = pushed_regs.pop() {
                self.asm_text.push_str(self.asm_fmt.get_pop(&poped).as_str());
            }
        } else {
            panic!();
        }
    }
}
